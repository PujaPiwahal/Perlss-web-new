import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-person-reconciliation',
  templateUrl: './person-reconciliation.component.html',
  styleUrls: ['./person-reconciliation.component.scss']
})
export class PersonReconciliationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
