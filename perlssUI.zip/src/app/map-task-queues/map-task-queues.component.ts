import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-map-task-queues',
  templateUrl: './map-task-queues.component.html',
  styleUrls: ['./map-task-queues.component.scss']
})
export class MapTaskQueuesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
