import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-waiting-list-management',
  templateUrl: './waiting-list-management.component.html',
  styleUrls: ['./waiting-list-management.component.scss']
})
export class WaitingListManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
