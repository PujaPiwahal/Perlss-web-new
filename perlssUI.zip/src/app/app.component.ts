import {Component, OnInit} from '@angular/core';
import {Router, NavigationEnd} from '@angular/router';
import {filter} from 'rxjs/operators';
import {AuthenticationService} from './core/authentication/authentication.service';
import {User} from './core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit{
  title = 'PERLSS';
  currentUser: User;
  currentUrl: string;
  isLoginPage = true;

  constructor(private router: Router,
              private authenticationService: AuthenticationService) {  }
  ngOnInit() {
    this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.currentUrl = event.url;
      if (this.currentUrl === '/') {
        this.currentUrl = '/login';
      }
      this.checkRoute();
    });
      }
  checkRoute() {
    if (this.currentUrl === '/login' || this.currentUser == null){
      this.isLoginPage = true;
    }
    else if (this.currentUser != null && this.currentUrl !== '/login'){
      this.isLoginPage = false;
    }
  }
}

