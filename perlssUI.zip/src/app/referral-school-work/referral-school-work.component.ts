import { Component, OnInit } from '@angular/core';
import { RefSchAndWork } from '../_shared/model/RefSchAndWork'
import { FormGroup, FormBuilder } from '@angular/forms';
import { ReferralService } from '../core/services/referral/referral.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-referral-school-work',
  templateUrl: './referral-school-work.component.html',
  styleUrls: ['./referral-school-work.component.scss']
})
export class ReferralSchoolWorkComponent implements OnInit {
  inSchool = false;
  schAndWorkForm : FormGroup;
  hlthDisSw =false;
  jobNowSw: string;
	jobOfferSw: string;
  lostJobSw: string;
  noJobSw: string;
  noJobExplWorkSw: string
  noWorkIntrstSw: string;
  //jobVocRehabSw: string;

  age : number;
  constructor(private fb: FormBuilder,private router:Router, private referralService:ReferralService) { }

  ngOnInit(): void {
    this.schAndWorkForm = this.fb.group({
      curSchoolSw: [''],
      leaveHsPsSw: [''],
      vocRehabSw: [''],
      srvcCallExplreSw:[''],
      jobSW: [''],
      empName: [''],
      jobEndDt: [''],
      jobEndReasonCd: [''],
      needSrvcsForJobSw: [''],
      hlthDisbltySw: [''],
      needhelpSW: [''],
      jobVocRehabSw: ['']
    });
  }

  saveSchoolAndWork() {
    const refSchAndWork = new RefSchAndWork(null,this.getFormData().curSchoolSw.value,this.getFormData().empName.value
    ,this.getFormData().hlthDisbltySw.value,this.getFormData().jobEndDt.value,this.getFormData().jobEndReasonCd.value
    ,this.jobNowSw,this.jobOfferSw,this.getFormData().jobVocRehabSw.value,this.getFormData().leaveHsPsSw.value
    ,null,this.lostJobSw
    ,this.getFormData().needSrvcsForJobSw.value,this.noJobExplWorkSw,this.noJobSw
    ,this.noWorkIntrstSw,this.getFormData().srvcCallExplreSw.value,this.getFormData().vocRehabSw.value
    ,'RF0000001');

    this.referralService.saveReferralSchAndWork(refSchAndWork);
  }

  getFormData() {
    return this.schAndWorkForm.controls;
  }
  onCurSchool(event){
    if(event.value==='Y'){
      this.inSchool=true;
    }else{
      this.inSchool=false;
    }
  }

  onHeathDisablity(event){
    if(event.value==='Y'){
      this.hlthDisSw = true;
    }else{
      this.hlthDisSw = false;
    }
  }

  onJobOptSelection(event) {
    if(event.value==='jobNow') {
      this.jobNowSw='Y';
    }else {
      this.jobNowSw='N';
    }
    if(event.value==='jobOfferSW') {
      this.jobOfferSw = 'Y';
    }else {
      this.jobOfferSw = 'N';
    }
    if(event.value==='lostJobSW') {
      this.lostJobSw = 'Y';
    }else {
      this.lostJobSw = 'N';
    }
    if(event.value==='needJobHelp') {
      this.noJobSw= 'Y';
    }else {
      this.noJobSw= 'N';
    }
    if(event.value==='noJobExplore') {
      this.noJobExplWorkSw = 'Y';
    }else {
      this.noJobExplWorkSw = 'N';
    }
    if(event.value==='notIntrestedInWork') {
      this.noWorkIntrstSw = 'Y';
    }else {
      this.noWorkIntrstSw = 'N';
    }
  }

  saveAndExit() {
    this.saveSchoolAndWork();
  }

  next() {
    this.saveSchoolAndWork();
    this.router.navigate(['/dashboard/referralCareAndSupport']);
  }

  back() {
    this.router.navigate(['/dashboard/referralContact'])
  }

}
