import { Component, OnInit } from '@angular/core';
import { MatRadioChange } from '@angular/material/radio';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ReferralService } from '../core/services/referral/referral.service';
import { RefAppContact } from '../_shared/model/RefAppContact';
import { Router } from '@angular/router';


@Component({
  selector: 'app-ref-contact',
  templateUrl: './ref-contact.component.html',
  styleUrls: ['./ref-contact.component.scss']
})
export class RefContactComponent implements OnInit {

  refContactForm: FormGroup;
  isDesignee = false;
  interpreterSW = false;
  designeeMailSW = false;
  ageSW = false;
  addrFormatSW = false;
  othLivingArrange = false;
  livingSelfSw = false;
  livingFamilySw = false;
  livingElseSw = false;
  moveOutSoonSw = false;
  helpRightAwaySw = false;
  lostPlaceSw = false;
  anotherPlaceSw = false;
  nursingHomeSW = false;
  otherfacilityCD = false;
  constructor(private fb: FormBuilder, private refService: ReferralService, private router: Router) { }
  getFormData() {
    return this.refContactForm.controls;
  }
  ngOnInit(): void {
    let age = this.refService.getAge();
    age = 20;
    console.log(age);
    if (age >= 18) {

      this.ageSW = true;
    }

    this.refContactForm = this.fb.group({
      anotherPlaceSw: [''],
      cellPhNum: [''],
      currentLivingCd: [''],
      designeeSw: [''],
      dsgnAaAeApCd: [''],
      dsgnAddrL2Dsgn: [''],
      dsgnAddrLine1: [''],
      dsgnAddressFormatCd: [''],
      dsgnApoFpoCd: [''],
      dsgnCity: [''],
      dsgnCntyCd: [''],
      dsgnFirstName: [''],
      dsgnLastName: [''],
      dsgnMailSw: [''],
      dsgnMidInitial: [''],
      dsgnStateCd: [''],
      dsgnZipExtn: [''],
      dsgnZipcode: [''],
      emailAddr: [''],
      facilityCd: [''],
      facilityOther: [''],
      helpRightAwaySw: [''],
      homePhNum: [''],
      interprtSw: [''],
      langCd: [''],
      livingElseSw: [''],
      livingFamilySw: [''],
      livingSelfSw: [''],
      lostPlaceSw: [''],
      moveOutSoonSw: [''],
      needServicesSw: [''],
      othLivingArrange: [''],
      prefPhoneTypCd: [''],
      relationshipCd: [''],
      workPhNum: [''],
      dsgnPhNum: [''],
      livingCd: [''],
      preflangCd: ['']

    });

  }
  saveAndExit() {
    this.saveRefandContact();
  }

  next() {
    this.saveRefandContact();
    this.router.navigate(['/dashboard/referralSchoolAndWork']);
  }
  saveRefandContact() {

    const refAppContact = new RefAppContact(this.getFormData().anotherPlaceSw.value, this.getFormData().cellPhNum.value,
      this.getFormData().currentLivingCd.value, this.getFormData().designeeSw.value, this.getFormData().dsgnAaAeApCd.value,
      this.getFormData().dsgnAddrL2Dsgn.value, this.getFormData().dsgnAddrLine1.value, this.getFormData().dsgnAddressFormatCd.value,
      this.getFormData().dsgnApoFpoCd.value, this.getFormData().dsgnCity.value, this.getFormData().dsgnCntyCd.value, this.getFormData().dsgnFirstName.value,
      this.getFormData().dsgnLastName.value, this.sendingYorN(this.designeeMailSW), this.getFormData().dsgnMidInitial.value, this.getFormData().dsgnStateCd.value,
      this.getFormData().dsgnZipExtn.value, this.getFormData().dsgnZipcode.value, this.getFormData().emailAddr.value, this.getFormData().facilityCd.value,
      this.getFormData().facilityOther.value, this.sendingYorN(this.helpRightAwaySw), this.getFormData().homePhNum.value, this.sendingYorN(this.interpreterSW),
      this.getFormData().langCd.value, this.sendingYorN(this.livingElseSw), this.sendingYorN(this.livingFamilySw), this.sendingYorN(this.livingSelfSw),
      this.sendingYorN(this.lostPlaceSw), this.sendingYorN(this.moveOutSoonSw), this.getFormData().needServicesSw.value,
      this.getFormData().othLivingArrange.value, 1000087, this.getFormData().prefPhoneTypCd.value,
      this.getFormData().relationshipCd.value, this.getFormData().workPhNum.value, this.getFormData().preflangCd.value, this.getFormData().dsgnPhNum.value, 'RF0000027', 'RFCON');
    this.refService.saveRefContact(refAppContact);
    console.log("county code value" + this.getFormData().dsgnCntyCd.value);
    console.log("dsgnPhNum" + this.getFormData().dsgnPhNum.value);
    console.log("livingCd" + this.getFormData().livingCd.value);
    console.log("currentLivingCd" + this.getFormData().currentLivingCd.value);
    console.log("preflangCd" + this.getFormData().preflangCd.value);
    console.log("Save Contact Referral Called");

  }

  sendingYorN(input: boolean) {
    if (input == true) {
      return 'Y';
    } else if (input == false) {
      return 'N';
    }
  }


  onDesigneeChange(mrChange: MatRadioChange) {

    if (mrChange.value === 'Y') {
      this.isDesignee = true;

    } else if (mrChange.value === 'N') {
      this.isDesignee = false;
    }
  }

  onInterpreterChange(mrChange: MatRadioChange) {

    if (mrChange.value === 'Y') {
      this.interpreterSW = true;
    } else if (mrChange.value === 'N') {
      this.interpreterSW = false;
    }
  }

  onDesigneeMailChange(mrChange: MatRadioChange) {
    if (mrChange.value === 'N') {
      this.designeeMailSW = false;
    }
    else if (mrChange.value === 'Y') {
      this.designeeMailSW = true;
    }
  }
  onMoveOutSoon(mrChange: MatRadioChange) {
    if (mrChange.value === 'N') {
      this.moveOutSoonSw = false;
    }
    else if (mrChange.value === 'Y') {
      this.moveOutSoonSw = true;
    }
  }

  onlostPlaceChange(mrChange: MatRadioChange) {
    if (mrChange.value === 'N') {
      this.lostPlaceSw = false;
    }
    else if (mrChange.value === 'Y') {
      this.lostPlaceSw = true;
    }
  }

  onhelpRightAwayChange(mrChange: MatRadioChange) {
    if (mrChange.value === 'N') {
      this.helpRightAwaySw = false;
    }
    else if (mrChange.value === 'Y') {
      this.helpRightAwaySw = true;
    }
  }

  onAnotherPlaceChange(mrChange: MatRadioChange) {
    if (mrChange.value === 'N') {
      this.anotherPlaceSw = false;
    }
    else if (mrChange.value === 'Y') {
      this.anotherPlaceSw = true;
    }
  }
  onAddressFormat(event) {
    if (event.target.value === 'MLTY') {
      this.addrFormatSW = true;
    } else {
      this.addrFormatSW = false;
    }
  }
  onCurrentLivingArrangement(event) {
    if (event.target.value === 'Other') {
      this.othLivingArrange = true;
      this.nursingHomeSW = false;
    } else if (event.target.value === 'Nursing Home' || event.target.value === 'ICF') {
      this.nursingHomeSW = true;
      this.othLivingArrange = false;
    }
  }

  onFacilityCd(event) {
    if (event.target.value === 'Other') {
      this.otherfacilityCD = true;
    }
  }

  onLivingChange(event) {
    if (event.target.value === 'livingByMySelf') {
      this.livingSelfSw = true;
    } else if (event.target.value === 'livingFamily') {
      this.livingFamilySw = false;
    } else if (event.target.value === 'livingelse') {
      this.livingElseSw = false;
    }
  }

  back() {
    this.router.navigate(['/dashboard/referralApplicant'])
  }
}



