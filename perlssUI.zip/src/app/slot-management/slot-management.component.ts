import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slot-management',
  templateUrl: './slot-management.component.html',
  styleUrls: ['./slot-management.component.scss']
})
export class SlotManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
