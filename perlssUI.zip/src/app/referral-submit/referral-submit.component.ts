import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ReferralService } from '../core/services/referral/referral.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { RefSubmission } from '../_shared/model/RefSubmission'

@Component({
  selector: 'app-referral-submit',
  templateUrl: './referral-submit.component.html',
  styleUrls: ['./referral-submit.component.scss']
})
export class ReferralSubmitComponent implements OnInit {

  refSubmissionForm: FormGroup;
  constructor(private fb: FormBuilder,private router: Router, private referralService: ReferralService) { }

  submitter: string;
  contactPerson: string;
  ngOnInit(): void {
    this.refSubmissionForm = this.fb.group({
      whoIsSubmittingCd: [''],
      relationshipCd: [''],
      expeditedReviewSw: [''],
      admissionDt:[''],
      planTransitionDt: [''],
      refContactCd: [''],
      refContactName: [''],
      othRelationshipCd: [''],
      emailAddr: [''],
      phNum: [''],
      signature: ['']
    
    });
  }

  
  saveAndExit() {
    this.saveRefSubmission();
  }

  next() {
    this.saveRefSubmission();
    this.router.navigate(['/dashboard/referralConfirmation']);
  }

  back() {
    this.router.navigate(['/dashboard/referralCareAndSupport']);
  }

  saveRefSubmission(){
    const refSubmission = new RefSubmission(null,this.getFormData().admissionDt.value,this.getFormData().emailAddr.value
    ,this.getFormData().expeditedReviewSw.value,this.getFormData().othRelationshipCd.value,this.getFormData().phNum.value
    ,this.getFormData().planTransitionDt.value,this.getFormData().refContactCd.value
    ,this.getFormData().refContactName.value,'RF0000001'
    ,this.getFormData().relationshipCd.value,this.getFormData().signature.value
    ,this.getFormData().whoIsSubmittingCd.value,'RFSUB');

    this.referralService.saveReferralSubmission(refSubmission);
  }

  getFormData() {
    return this.refSubmissionForm.controls;
  }

  onSelect(event){
    this.submitter=event.target.value;
  }

  onContactPersonSelect(event){
    this.contactPerson=event.target.value;
  }
}
