import { Component, OnInit } from '@angular/core';
import { User } from '../core';
import { Router, NavigationEnd } from '@angular/router';
import { AuthenticationService } from '../core/authentication/authentication.service';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-pae',
  templateUrl: './pae.component.html',
  styleUrls: ['./pae.component.scss']
})
export class PaeComponent implements OnInit{

  isSideNavToggled = true;
  perlsSideNavContentWidth = 280;
  isLoginPage = true;
  currentUrl: string;
  pageHeader = 'Home';
  isPersonDetailsDropDownToggled = false;
  isLtssFunctionsDropDownToggled = true;
  isAdminDropDownToggled = true;
  isHighlighted = false;
  currentUser: User;

  constructor(private router: Router,
              private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.currentUrl = event.url;
      if (this.currentUrl === '/') {
        this.currentUrl = '/login';
      }
      this.setPageHeader();
      window.scrollTo(0, 0);
    });
    this.setPageHeader();
  }

  toggleSideNav() {
    this.isSideNavToggled = !this.isSideNavToggled;
    console.log(this.isSideNavToggled);
    if (!this.isSideNavToggled){
      this.perlsSideNavContentWidth = 60;
    }
    else {
      this.perlsSideNavContentWidth = 280;
    }
  }

  setPageHeader() {
    this.isHighlighted = false;
    if (this.currentUrl !== '/login' && this.currentUser == null){
      this.pageHeader = '';
    }
    if (this.currentUser != null) {
      if (this.currentUrl === '/dashboard/pae/applicantInformation'){
        this.pageHeader = 'Applicant Information';
        this.isHighlighted = true;
      }
      if (this.currentUrl === '/dashboard/pae/contactInformation'){
        this.pageHeader = 'Contact Information';
        this.isHighlighted = true;
      }
      if (this.currentUrl === '/dashboard/pae/livingArrangement'){
        this.pageHeader = 'Living Arrangement';
        this.isHighlighted = true;
      }
      if (this.currentUrl === '/dashboard/pae/selectProgram'){
        this.pageHeader = 'Select Program';
        this.isHighlighted = true;
      }
      if (this.currentUrl === '/dashboard/pae/appointment'){
        this.pageHeader = 'Appointment';
        this.isHighlighted = true;
      }
    }
  }

  toggleDropDown(dropDown) {
    if (dropDown === 'personDetails') {
      this.isPersonDetailsDropDownToggled = !this.isPersonDetailsDropDownToggled;
    }
    if (dropDown === 'ltssFunctions') {
      this.isLtssFunctionsDropDownToggled = !this.isLtssFunctionsDropDownToggled;
    }
    if (dropDown === 'admin') {
      this.isAdminDropDownToggled = !this.isAdminDropDownToggled;
    }
  }
}

