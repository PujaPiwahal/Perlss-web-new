import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-map-business-functions',
  templateUrl: './map-business-functions.component.html',
  styleUrls: ['./map-business-functions.component.scss']
})
export class MapBusinessFunctionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
