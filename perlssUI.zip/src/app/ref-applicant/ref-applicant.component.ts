import { Component, OnInit, ViewChild } from '@angular/core';
import { RefMedDtl } from '../_shared/model/RefMedDtl';
import { RefCoreDtl } from '../_shared/model/RefCoreDtl';
import { Applicant } from '../_shared/model/Applicant';
import { ApplicantAddress } from '../_shared/model/ApplicantAddress';
import { MatStepper } from '@angular/material/stepper';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ReferralService } from '../core/services/referral/referral.service';
import { MatRadioChange } from '@angular/material/radio';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ref-applicant',
  templateUrl: './ref-applicant.component.html',
  styleUrls: ['./ref-applicant.component.scss'],
  //providers: [ReferralService]
})
export class RefApplicantComponent implements OnInit {

  isSearchPerson = false;
  myForm: FormGroup;
  constructor(private fb: FormBuilder, private refService: ReferralService, private router: Router) { }
  refApplicantForm: FormGroup;
  age: number;
  refMedDtl: RefMedDtl;

  alternateNameSW = false;
  mailAddrSW = true;;

  addrFormatSW = false;
  mailAddrFormatSW = false;
  ngOnInit(): void {

    this.refApplicantForm = this.fb.group({
      firstName: [''],
      lastName: [''],
      midInitial: [''],
      birthDt: [''],
      suffix: [''],
      genderCd: [''],
      ssn: [''],
      aliasFirstName: [''],
      aliasLastName: [''],
      aliasMidInitial: [''],
      ssnAvailableSw: [''],
      altNameSw: [''],
      addressFormatCd: [''],
      aliasSuffix: [''],
      addrLine1: [''],
      addrLine2: [''],
      stateCd: [''],
      city: [''],
      zipcode: [''],
      zipExt: [''],
      cntyCd: [''],
      apoFpoCd: [''],
      aaAeApCd: [''],
      mailAddrSw: [''],
      mailAddressFormatCd: [''],
      mailAddrLine1: [''],
      mailAddrLine2: [''],
      mailCity: [''],
      mailState: [''],
      mailZip: [''],
      mailZipExtn: [''],
      mailCounty: ['']
    });
  }

  ngAfterViewInit() {
    //this.stepper.selectedIndex=1;
  }

  calculateAge(event) {
    const today = new Date();
    const birthDate = new Date(event.value);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    this.age = age;
    this.refService.setAge(age);
  }
  getFormData() {
    return this.refApplicantForm.controls;
  }
  saveRefandApplicant() {
    const addressVO = new ApplicantAddress(this.getFormData().mailAddrLine1.value
      , this.getFormData().mailAddrLine2.value, this.getFormData().mailCity.value
      , this.getFormData().mailCounty.value, this.getFormData().mailState.value
      , this.getFormData().mailZip.value, this.getFormData().mailZipExtn.value
      , '', this.getFormData().mailAddrSw.value
      , '', this.getFormData().addrLine1.value, this.getFormData().addrLine2.value
      , this.getFormData().city.value, this.getFormData().cntyCd.value, this.getFormData().stateCd.value
      , this.getFormData().zipcode.value, this.getFormData().zipExt.value
      , this.getFormData().addressFormatCd.value, '');

    const applicant = new Applicant(this.getFormData().aliasFirstName.value, this.getFormData().aliasLastName.value
      , this.getFormData().aliasMidInitial.value, this.getFormData().aliasSuffix.value
      , this.getFormData().altNameSw.value, this.getFormData().birthDt.value
      , '1000076', 'N', 'N', 'N', this.getFormData().firstName.value, this.getFormData().genderCd.value, 'N', 'N', ''
      , this.getFormData().lastName.value, this.getFormData().midInitial.value,
      '', this.getFormData().ssn.value, this.getFormData().ssnAvailableSw.value, '', addressVO, true);

    this.refMedDtl = this.refService.getRefMedDtl();
    const refCoreDtl = new RefCoreDtl('RF0000002', '', '', 'Pending', applicant, this.refMedDtl);
    this.refService.saveReferral(refCoreDtl);
    this.router.navigate(['/dashboard/referralContact']);
    console.log("Save Referral Called");
  }

  searchPerson() {
    this.isSearchPerson = true;
    console.log(this.isSearchPerson);
  }

  onAlternateNameChange(mrChange: MatRadioChange) {
    if (mrChange.value === 'N') {
      this.alternateNameSW = false;
    }
    else if (mrChange.value === 'Y') {
      this.alternateNameSW = true;
    }
  }

  onMailAddrChange(mrChange: MatRadioChange) {
    if (mrChange.value === 'N') {
      this.mailAddrSW = false;
    }
    else if (mrChange.value === 'Y') {
      this.mailAddrSW = true;
    }
  }
  onMailAddressFormat(event) {
    if (event.target.value === 'MLTY') {
      this.mailAddrFormatSW = true;
    } else {
      this.mailAddrFormatSW = false;
    }

  }
  onAddressFormat(event) {
    if (event.target.value === 'MLTY') {
      this.addrFormatSW = true;
    } else {
      this.addrFormatSW = false;
    }
  }

  back() {
    this.router.navigate(['/dashboard/referral'])
  }
}
