import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-pae-appointment',
  templateUrl: './pae-appointment.component.html',
  styleUrls: ['./pae-appointment.component.scss']
})
export class PaeAppointmentComponent implements OnInit {
  myForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      contactMethod: [''],
      cellPhone: [''],
      homePhone: [''],
      workPhone: [''],
      designeeFirstName: [''],
      designeeMiddleName: [''],
      designeeLastName: [''],
      designeeRelationship: [''],
      childRecordRights: [''],
      language: ['']
    });
  }

  scheduleAppointment() {}

}
