import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ref-confirmation',
  templateUrl: './ref-confirmation.component.html',
  styleUrls: ['./ref-confirmation.component.scss']
})
export class RefConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
