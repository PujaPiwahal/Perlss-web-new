import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-pae-living-arrangement',
  templateUrl: './pae-living-arrangement.component.html',
  styleUrls: ['./pae-living-arrangement.component.scss']
})
export class PaeLivingArrangementComponent implements OnInit {
  myForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      currentLivingArrangement: [''],
      describeLivingArrangement: [''],
      nursingFacilityName: [''],
      addressLine1: [''],
      addressLine2: [''],
      city: [''],
      state: [''],
      zipCode: [''],
      ext: [''],
      county: [''],
      phoneNumber: ['']
    });
  }
  saveLivingArrangement() {}

}
