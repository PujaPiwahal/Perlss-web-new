import { CustomvalidationService } from './../_shared/utility/customvalidation.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as customValidation from '../_shared/constants/validation.constants';
import { MatRadioChange } from '@angular/material/radio';

@Component({
  selector: 'app-pae-applicant-information',
  templateUrl: './pae-applicant-information.component.html',
  styleUrls: ['./pae-applicant-information.component.scss']
})
export class PaeApplicantInformationComponent implements OnInit {
  searchForm: FormGroup;
  isSearchPerson = false;
  isAlias = true;
  customValidation = customValidation;
  minDate: Date;
  maxDate: Date;
  constructor(private fb: FormBuilder,
              private customValidator: CustomvalidationService) { }

  ngOnInit() {
    const currentYear = new Date().getFullYear();
    this.minDate = new Date(currentYear - 119, 0, 1);
    this.maxDate = new Date();
    this.searchForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.maxLength(45), this.customValidator.nameValidator()]],
      mi: ['', [Validators.maxLength(1), Validators.pattern('^[a-zA-Z]*$')]],
      lastName: ['', [Validators.required, Validators.maxLength(45), this.customValidator.nameValidator()]],
      suffix: [''],
      dateOfBirth: ['', [Validators.required]],
      ssn: [''],
      aliasFirstName: ['', [Validators.required, Validators.maxLength(45), this.customValidator.nameValidator()]],
      aliasMi: ['', [Validators.maxLength(1), Validators.pattern('^[a-zA-Z]*$')]],
      aliasLastName: ['', [Validators.required, Validators.maxLength(45), this.customValidator.nameValidator()]],
      aliasSuffix: [''],
      addressFormat: [''],
      addressLine1: ['', [Validators.required, Validators.maxLength(100), this.customValidator.addressAndCityValidator()]],
      addressLine2: ['', [Validators.maxLength(50), this.customValidator.addressAndCityValidator()]],
      city: ['', [Validators.required, Validators.maxLength(25), this.customValidator.addressAndCityValidator()]],
      state: ['', [Validators.required]],
      zipCode: ['', [Validators.required, Validators.pattern('[0-9]{5}') , this.customValidator.specialCharacterValidator()]],
      ext: ['', Validators.pattern('[0-9]') ],
      county: ['', [Validators.required]]
    });
  }

get f() { return this.searchForm.controls; }


searchPerson() {
  this.isSearchPerson = true;
  console.log(this.isSearchPerson);
}

onChange(mrChange: MatRadioChange) {
  console.log(mrChange.value);
  if (mrChange.value === 'no') {
    this.isAlias = false;
  }
  else if (mrChange.value === 'yes') {
    this.isAlias = true;
  }
}

}
