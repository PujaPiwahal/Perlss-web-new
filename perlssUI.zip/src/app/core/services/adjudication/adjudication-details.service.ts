import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdjudicationDetailsService {
  private parentId: any;

  constructor(private http: HttpClient) { }

  setAdjudicationSearchParentId(parentId) {
    this.parentId = parentId;
  }
  getAdjudicationSearchParentId() {
    return this.parentId;
  }

  getAdjudicationDetails(parentId): Observable<any[]> {
    let paramss = new HttpParams();
    paramss = paramss.append('parentId', String(parentId));
    return this.http.get<any[]>(`${environment.apiUrl}/audit/searchDetails`, {params: paramss});
  }

}
