import { Injectable } from '@angular/core';
import { RefMedDtl } from 'src/app/_shared/model/RefMedDtl';
import { RefCoreDtl } from 'src/app/_shared/model/RefCoreDtl';
import { HttpClient} from '@angular/common/http/';
import { environment } from 'src/environments/environment';
import { RefSchAndWork } from 'src/app/_shared/model/RefSchAndWork';
import { RefSubmission } from 'src/app/_shared/model/RefSubmission';
import { RefAppContact } from 'src/app/_shared/model/RefAppContact';
import { RefCareAndSupport } from 'src/app/_shared/model/RefCareAndSupport';

@Injectable({
  providedIn: 'root'
})
export class ReferralService {
  age:number;
  constructor(private http: HttpClient) { }
  response:any;
  refMedDtl: RefMedDtl
  setRefMedDtl( refMedDtl: RefMedDtl){
    this.refMedDtl=refMedDtl;
  }

  getRefMedDtl(){
    return this.refMedDtl;
  }

  setAge(age:number){
    this.age=age;
  }
  getAge(){
    return this.age;
  }

  saveReferral(refCoreDtl: RefCoreDtl) { 
     this.http.post<any>(`${environment.apiUrl}/referral/addReferral`, refCoreDtl).subscribe(data => {
      this.response = data;
  });
  }

  saveReferralSchAndWork(refSchAndWork: RefSchAndWork) { 
    this.http.post<any>(`${environment.apiUrl}/referral/schoolAndWrokInfo`, refSchAndWork).subscribe(data => {
     this.response = data;
 });
}

 saveReferralSubmission(refSubmission: RefSubmission) { 
  this.http.post<any>(`${environment.apiUrl}/referral/submitReferral`, refSubmission).subscribe(data => {
   this.response = data;
  });
 }

 saveRefContact(refAppContact: RefAppContact) { 
  this.http.post<any>(`${environment.apiUrl}/referral/addReferralContact`, refAppContact).subscribe(data => {
   this.response = data;
});
}

saveRefCareAndSupport(refCareAndSupport: RefCareAndSupport) { 
this.http.post<any>(`${environment.apiUrl}/referral/careAndSupportInfo`, refCareAndSupport).subscribe(data => {
 this.response = data;
});
}
}
