import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient, HttpParams} from '@angular/common/http';
import {environment} from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuditDetailsService {
  private parentId: any;

  constructor(private http: HttpClient) {
  }

  setAuditSearchParentId(parentId) {
    this.parentId = parentId;
  }

  getAuditSearchParentId() {
    return this.parentId;
  }

  getAuditDetails(parentId): Observable<any[]> {
    let paramss = new HttpParams();
    paramss = paramss.append('parentId', String(parentId));
    return this.http.get<any[]>(`${environment.apiUrl}/audit/searchDetails`, {params: paramss});
  }
}
