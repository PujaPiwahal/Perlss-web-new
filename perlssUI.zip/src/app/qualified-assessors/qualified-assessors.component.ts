import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qualified-assessors',
  templateUrl: './qualified-assessors.component.html',
  styleUrls: ['./qualified-assessors.component.scss']
})
export class QualifiedAssessorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
