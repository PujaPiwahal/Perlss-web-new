import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transitions',
  templateUrl: './transitions.component.html',
  styleUrls: ['./transitions.component.scss']
})
export class TransitionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
