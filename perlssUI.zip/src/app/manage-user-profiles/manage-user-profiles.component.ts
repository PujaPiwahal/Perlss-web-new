import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-user-profiles',
  templateUrl: './manage-user-profiles.component.html',
  styleUrls: ['./manage-user-profiles.component.scss']
})
export class ManageUserProfilesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
