import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-management',
  templateUrl: './change-management.component.html',
  styleUrls: ['./change-management.component.scss']
})
export class ChangeManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
