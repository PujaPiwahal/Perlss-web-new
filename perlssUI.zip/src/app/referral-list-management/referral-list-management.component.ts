import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-referral-list-management',
  templateUrl: './referral-list-management.component.html',
  styleUrls: ['./referral-list-management.component.scss']
})
export class ReferralListManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
