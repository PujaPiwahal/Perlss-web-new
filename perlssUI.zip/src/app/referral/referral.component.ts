import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { RefMedDtl } from '../_shared/model/RefMedDtl';
import { ReferralService } from '../core/services/referral/referral.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-new-referral',
  templateUrl: './referral.component.html',
  styleUrls: ['./referral.component.scss']
})
export class ReferralComponent implements OnInit {

  isLinear = true;
  referralForm: FormGroup;
  isDevlopmentDisability =false;

  constructor(private fb: FormBuilder,private refService:ReferralService,private router:Router) {}

  ngOnInit() {
    this.referralForm = this.fb.group({
      intelDisableSw: new FormControl(false, Validators.required) ,
      devDisableSw: [false],
      diagnosisTxt: [''],
    });
  }

  getData() {
    return this.referralForm.controls;
  }

  next(){
    let intDisbaleSw = this.getData().intelDisableSw.value ? 'Y' : 'N';
    let dDisableSw = this.getData().devDisableSw.value ? 'Y' : 'N'
    const refMedDtl = new RefMedDtl(intDisbaleSw,dDisableSw,this.getData().diagnosisTxt.value);  
    this.refService.setRefMedDtl(refMedDtl);
    this.router.navigate(['/dashboard/referralApplicant']);
  }

  validateAllFields(formGroup: FormGroup) {         
    Object.keys(formGroup.controls).forEach(field => {  
        const control = formGroup.get(field);            
        if (control instanceof FormControl) {             
            control.markAsTouched({ onlySelf: true });
        } else if (control instanceof FormGroup) {        
            this.validateAllFields(control);  
        }
    });
}

onDevlopDisablitySelect(event){
  if(event.target.checked){
    this.isDevlopmentDisability=true;
  }else{
    this.isDevlopmentDisability=false;
  }
}


}
