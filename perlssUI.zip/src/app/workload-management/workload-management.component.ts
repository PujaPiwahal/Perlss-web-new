import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workload-management',
  templateUrl: './workload-management.component.html',
  styleUrls: ['./workload-management.component.scss']
})
export class WorkloadManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
