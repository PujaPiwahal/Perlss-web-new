export class RefAppContact {
    constructor(
    

	public  anotherPlaceSw,

	public  cellPhNum,

	public  currentLivingCd,

	public  designeeSw,

	public  dsgnAaAeApCd,

	public  dsgnAddrL2Dsgn,

	public  dsgnAddrLine1,

	public  dsgnAddressFormatCd,

	public  dsgnApoFpoCd,

	public  dsgnCity,

	public  dsgnCntyCd,

	public  dsgnFirstName,

	public  dsgnLastName,

	public  dsgnMailSw,

	public  dsgnMidInitial,

	public  dsgnStateCd,

	public  dsgnZipExtn,

	public  dsgnZipcode,

	public  emailAddr,

	public  facilityCd,

	public  facilityOther,

	public  helpRightAwaySw,

	public  homePhNum,

	public  interprtSw,

	public  langCd,

	public  livingElseSw,

	public  livingFamilySw,

	public  livingSelfSw,

	public  lostPlaceSw,

	public  moveOutSoonSw,

	public  needServicesSw,

	public  othLivingArrange,

	public  personId,

	public  prefPhoneTypCd,

	public  relationshipCd,

	public  workPhNum,
	public prefLangTypeCd,
	public desgnPhNum,
	public refId,
	public reqPageId

      
      ) {  }
  }