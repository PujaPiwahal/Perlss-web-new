export class Person{
    constructor(
        public firstName: String,
        public lastName: string,
        public birthDate: any,
        public SSN: string,
        public personId: string,
        public country: string) {  }
}