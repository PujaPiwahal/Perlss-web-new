export class ApplicantAddress {
    constructor(
        public  mailAddrLine1: string,
    
        public  mailAddrLine2: string,
    
        public  mailCity: string,
    
        public  mailCounty: string,
    
        public  mailState: string,
    
        public  mailZip: string,
        
        public  mailZipExtn: string,
    
        public  mailValidAddressCd: string,

        public  mailAddrSw: string,
       
        public  personId: string,

        public addrLine1:string,
        
        public addrLine2:string,
        
        public city:string,

        public cntyCd:string,

        public  stateCd: string,
        
        public  zipcode: string,

        public  zipExtn: string,

        public addressFormatCd: string,

        public  validAddressCd: string,
      
      ) {  }
  }