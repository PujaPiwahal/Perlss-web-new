export class RefMedDtl{
    constructor(
        public intelDisableSw: String,
        public devDisableSw: string,
        public diagnosisTxt: string,
       ) {  }
}