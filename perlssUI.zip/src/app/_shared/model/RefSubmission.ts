export class RefSubmission {
    constructor(
    private  id,

	private  admissionDt,

	private  emailAddr,

	private  expeditedReviewSw,

	private  othRelationshipCd,

	private  phNum,

	private  planTransitionDt,
	
	private  refContactCd,

	private  refContactName,
	
	private  refId,

	private  relationshipCd,
	
	private  signature,

    private  whoIsSubmittingCd,
    
    private reqPageId
    ){}

}