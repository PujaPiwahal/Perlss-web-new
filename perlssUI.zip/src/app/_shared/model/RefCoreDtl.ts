import {RefMedDtl} from './RefMedDtl';
import {Applicant} from './Applicant';
export class RefCoreDtl {
    constructor(
      public refId: string,
      public externalRefSw: string,
      public pdfGeneratedSw: string,
      public refStatus: string,
      public applcantVO: Applicant,
      public refMedDtl: RefMedDtl
      
      ) {  }
  }