export class RefCareAndSupport {
    constructor(
        public abuseNeglectedSw: string,


        public adultProtectServSw: string,


        public anotherCareGiverSw: string,


        public antrPlaceSw: string,
        public age,
        public behaNoneSw: string,


        public behaServicesSw: string,




        public careGiverBirthDt,


        public careGiverDiedSw: string,


        public careGiverName: string,


        public careGiverRelCd: string,


        public childProtectServSw: string,


        public cleaningDressSw: string,


        public criminalJustSw: string,


        public eatingSw: string,


        public goodDecisionsSafeSw: string,


        public knowFamilySw: string,


        public medicinesSw: string,


        public mentalHlthCrisisSw: string,


        public noneOfAboveSw: string,


        public personHelpNoneSw: string,


        public physHurtBehaSw: string,


        public primCaregiverSw: string,


        public primCrgiverDisablSw: string,


        public primCrgvrPoorHlthSw: string,


        public psychHospSw: string,


        public resTreatProgSw: string,


        public tellingOthersSw: string,


        public transferBedChairToilSw: string,


        public underSimpleInstSw: string,


        public walkWheelchairSw: string,


        public refId: string,
        public reqPageId: string
    ) { }
}
