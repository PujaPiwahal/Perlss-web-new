export class RefSchAndWork {
    constructor(
    public  id,

	public  curSchoolSw,

	public  empName,

	public  hlthDisbltySw,

	public  jobEndDt,

	public  jobEndReasonCd,

	public  jobNowSw,

	public  jobOfferSw,

	public  jobVocRehabSw,

	public  leaveHsPsSw,

	public  liveDothingsSw,

	public  lostJobSw,

	public  needSrvcsForJobSw,

	public  noJobExplWorkSw,

	public  noJobSw,

	public  noWorkIntrstSw,

	public  srvcCallExplreSw,

	public  vocRehabSw,
	
	public  refId
       ) {  }
}