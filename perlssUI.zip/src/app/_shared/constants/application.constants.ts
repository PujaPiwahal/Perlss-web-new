// App constants for client-side
export const APP_STORAGE_TOKEN = 'AuthToken';
export const APP_STORAGE_USERNAME = 'userName';
export const APP_STORAGE_FIRSTNAME = 'firstName';
