import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ReferralService } from '../core/services/referral/referral.service';
import { Router } from '@angular/router';
import { MatStepper } from '@angular/material/stepper';
import { MatRadioChange } from '@angular/material/radio';
import { RefCareAndSupport } from '../_shared/model/RefCareAndSupport';

@Component({
  selector: 'app-ref-care-and-support',
  templateUrl: './ref-care-and-support.component.html',
  styleUrls: ['./ref-care-and-support.component.scss']
})
export class RefCareAndSupportComponent implements OnInit {
  refCareAndSuppportForm: FormGroup;
  primaryCareGiverSW = false;
  age: number;
  notPrimaryCareGiverSW = false;
  abuseNeglectedSW = false;
  physicalHurtSW = false;
  constructor(private fb: FormBuilder, private refService: ReferralService, private router: Router) { }
  getFormData() {
    return this.refCareAndSuppportForm.controls;
  }

  ngOnInit(): void {
    this.refCareAndSuppportForm = this.fb.group({
      abuseNeglectedSw: [''],

      adultProtectServSw: [''],

      anotherCareGiverSw: [''],

      antrPlaceSw: [''],
      age: [''],
      behaNoneSw: [''],

      behaServicesSw: [''],


      careGiverBirthDt: [''],

      careGiverDiedSw: [''],

      careGiverName: [''],

      careGiverRelCd: [''],

      childProtectServSw: [''],

      cleaningDressSw: [''],

      criminalJustSw: [''],

      eatingSw: [''],

      goodDecisionsSafeSw: [''],

      knowFamilySw: [''],

      medicinesSw: [''],

      mentalHlthCrisisSw: [''],

      noneOfAboveSw: [''],

      personHelpNoneSw: [''],

      physHurtBehaSw: [''],

      primCaregiverSw: [''],

      primCrgiverDisablSw: [''],

      primCrgvrPoorHlthSw: [''],

      psychHospSw: [''],

      resTreatProgSw: [''],

      tellingOthersSw: [''],

      transferBedChairToilSw: [''],

      underSimpleInstSw: [''],

      walkWheelchairSw: [''],
      toiletingSw: ['']


    });



  }

  saveRefarralCareAndSupport() {
    const refCareAndSupport = new RefCareAndSupport(this.getFormData().abuseNeglectedSw.value, this.getFormData().adultProtectServSw.value,

      this.getFormData().anotherCareGiverSw.value, this.getFormData().antrPlaceSw.value, this.age,
      this.sendingYorN(this.getFormData().behaNoneSw.value), this.sendingYorN(this.getFormData().behaServicesSw.value), this.getFormData().careGiverBirthDt.value, this.getFormData().careGiverDiedSw.value,
      this.getFormData().careGiverName.value, this.getFormData().careGiverRelCd.value, this.sendingYorN(this.getFormData().childProtectServSw.value),
      this.sendingYorN(this.getFormData().cleaningDressSw.value), this.sendingYorN(this.getFormData().criminalJustSw.value), this.sendingYorN(this.getFormData().eatingSw.value),
      this.sendingYorN(this.getFormData().goodDecisionsSafeSw.value), this.sendingYorN(this.getFormData().knowFamilySw.value), this.sendingYorN(this.getFormData().medicinesSw.value),
      this.sendingYorN(this.getFormData().mentalHlthCrisisSw.value), this.sendingYorN(this.getFormData().noneOfAboveSw.value), this.sendingYorN(this.getFormData().personHelpNoneSw.value),
      this.getFormData().physHurtBehaSw.value, this.getFormData().primCaregiverSw.value, this.sendingYorN(this.getFormData().primCrgiverDisablSw.value),
      this.sendingYorN(this.getFormData().primCrgvrPoorHlthSw.value), this.sendingYorN(this.getFormData().psychHospSw.value), this.sendingYorN(this.getFormData().resTreatProgSw.value),
      this.sendingYorN(this.getFormData().tellingOthersSw.value), this.sendingYorN(this.getFormData().transferBedChairToilSw.value), this.sendingYorN(this.getFormData().underSimpleInstSw.value),
      this.sendingYorN(this.getFormData().walkWheelchairSw.value), 'RF1000027', 'RFCARE');

    this.refService.saveRefCareAndSupport(refCareAndSupport);
    console.log('Save Care and Support done');

  }


  saveAndExit() {
    this.saveRefarralCareAndSupport();
  }

  next() {
    this.saveRefarralCareAndSupport();
    this.router.navigate(['/dashboard/submitReferral']);
  }

  back() {
    this.router.navigate(['/dashboard/referralSchoolAndWork']);
  }

  sendingYorN(input: boolean) {
    if (input == true) {
      return 'Y';
    } else if (input == false) {
      return 'N';
    }
  }
  calculateAge(event) {
    const today = new Date();
    const birthDate = new Date(event.value);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    this.age = age;
  }

  onPrimaryCareGiverChange(mrChange: MatRadioChange) {

    if (mrChange.value === 'Y') {
      this.primaryCareGiverSW = true;
      this.notPrimaryCareGiverSW = false;

    } else if (mrChange.value === 'N') {
      this.notPrimaryCareGiverSW = true;
      this.primaryCareGiverSW = false;
    }
  }
  onAbuseNeglectedChange(mrChange: MatRadioChange) {

    if (mrChange.value === 'Y') {
      this.abuseNeglectedSW = true;


    } else if (mrChange.value === 'N') {

      this.abuseNeglectedSW = false;
    }
  }

  onPhysicalHurtBehaviourChange(mrChange: MatRadioChange) {

    if (mrChange.value === 'Y') {
      this.physicalHurtSW = true;


    } else if (mrChange.value === 'N') {

      this.physicalHurtSW = false;
    }
  }
}
