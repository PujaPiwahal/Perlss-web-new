import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-user-roles',
  templateUrl: './manage-user-roles.component.html',
  styleUrls: ['./manage-user-roles.component.scss']
})
export class ManageUserRolesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
