import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-diagnosis-summary',
  templateUrl: './diagnosis-summary.component.html',
  styleUrls: ['./diagnosis-summary.component.scss']
})
export class DiagnosisSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
