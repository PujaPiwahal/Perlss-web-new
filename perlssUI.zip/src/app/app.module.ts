import { PaeComponent } from './pae/pae.component';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NgModule} from '@angular/core';
import {AppMaterialModule} from './_shared/app-material.module';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {HeaderComponent} from './core/header/header.component';
import {FooterComponent} from './core/footer/footer.component';
import {LoginComponent} from './login/login.component';
import {ReactiveFormsModule} from '@angular/forms';
import {UserDetailsComponent} from './user-details/user-details.component';
import {HTTP_INTERCEPTORS, HttpClientModule, HttpParams} from '@angular/common/http';
import {AuditHistoryComponent} from './audit-history/audit-history.component';
import {AuditDetailsComponent} from './audit-details/audit-details.component';
import {ErrorInterceptor} from './core/helpers/error.interceptor';
import {JwtInterceptor} from './core/helpers/jwt.interceptor';
import {TokenStorage} from './_shared/utility/TokenStorage';
import { LeftnavComponent } from './leftnav/leftnav.component';
import { PaeApplicantInformationComponent } from './pae/pae-applicant-information/pae-applicant-information.component';
import { PaeContactInformationComponent } from './pae/pae-contact-information/pae-contact-information.component';
import { PaeLivingArrangementComponent } from './pae/pae-living-arrangement/pae-living-arrangement.component';
import { PaeSelectProgramComponent } from './pae/pae-select-program/pae-select-program.component';
import { PaeAppointmentComponent } from './pae/pae-appointment/pae-appointment.component';
import { DiagnosisSummaryComponent } from './diagnosis-summary/diagnosis-summary.component';
import { InboxComponent } from './inbox/inbox.component';
import { ReferralComponent } from './referral/referral.component';
import { AppointmentsComponent } from './appointments/appointments.component';
import { DocumentsComponent } from './documents/documents.component';
import { NoticesComponent } from './notices/notices.component';
import { ChangeManagementComponent } from './change-management/change-management.component';
import { ReferralListManagementComponent } from './referral-list-management/referral-list-management.component';
import { WaitingListManagementComponent } from './waiting-list-management/waiting-list-management.component';
import { TransitionsComponent } from './transitions/transitions.component';
import { AdjudicationComponent } from './adjudication/adjudication.component';
import { EnrollmentComponent } from './enrollment/enrollment.component';
import { AppealsComponent } from './appeals/appeals.component';
import { ReportsComponent } from './reports/reports.component';
import { SlotManagementComponent } from './slot-management/slot-management.component';
import { ManageUserProfilesComponent } from './manage-user-profiles/manage-user-profiles.component';
import { ManageUserRolesComponent } from './manage-user-roles/manage-user-roles.component';
import { MapBusinessFunctionsComponent } from './map-business-functions/map-business-functions.component';
import { MapTaskQueuesComponent } from './map-task-queues/map-task-queues.component';
import { WorkloadManagementComponent } from './workload-management/workload-management.component';
import { QualifiedAssessorsComponent } from './qualified-assessors/qualified-assessors.component';
import { PersonReconciliationComponent } from './person-reconciliation/person-reconciliation.component';
import { AdjudicationSearchComponent } from './adjudication/adjudication-search/adjudication-search.component';
import { AdjudicationDetailsComponent } from './adjudication/adjudication-details/adjudication-details.component';
import {MatPaginatorModule} from '@angular/material/paginator';
import { RefApplicantComponent } from './ref-applicant/ref-applicant.component';
import { MatStepperModule } from '@angular/material/stepper';
import { ReferralSchoolWorkComponent } from './referral-school-work/referral-school-work.component';
import { ReferralSubmitComponent } from './referral-submit/referral-submit.component';
import { RefConfirmationComponent } from './ref-confirmation/ref-confirmation.component';
import { RefCareAndSupportComponent } from './ref-care-and-support/ref-care-and-support.component';
import { RefContactComponent } from './ref-contact/ref-contact.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    UserDetailsComponent,
    AuditHistoryComponent,
    AuditDetailsComponent,
    LeftnavComponent,
    PaeApplicantInformationComponent,
    PaeContactInformationComponent,
    PaeLivingArrangementComponent,
    PaeSelectProgramComponent,
    PaeAppointmentComponent,
    DiagnosisSummaryComponent,
    InboxComponent,
    ReferralComponent,
    AppointmentsComponent,
    DocumentsComponent,
    NoticesComponent,
    ChangeManagementComponent,
    ReferralListManagementComponent,
    WaitingListManagementComponent,
    TransitionsComponent,
    AdjudicationComponent,
    EnrollmentComponent,
    AppealsComponent,
    ReportsComponent,
    SlotManagementComponent,
    ManageUserProfilesComponent,
    ManageUserRolesComponent,
    MapBusinessFunctionsComponent,
    MapTaskQueuesComponent,
    WorkloadManagementComponent,
    QualifiedAssessorsComponent,
    PersonReconciliationComponent,
    AdjudicationSearchComponent,
    AdjudicationDetailsComponent,
    RefApplicantComponent,
    ReferralSchoolWorkComponent,
    ReferralSubmitComponent,
    RefConfirmationComponent,
    RefCareAndSupportComponent,
    RefContactComponent,
    PaeComponent
  ],
  exports:[MatPaginatorModule],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    AppMaterialModule,
    HttpClientModule,
    MatPaginatorModule,
    MatStepperModule
  ],
  providers: [TokenStorage,
    {provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true},
    {provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true}, ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
