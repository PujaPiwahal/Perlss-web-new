import { PaeComponent } from './pae/pae.component';
import { PersonReconciliationComponent } from './person-reconciliation/person-reconciliation.component';
import { QualifiedAssessorsComponent } from './qualified-assessors/qualified-assessors.component';
import { WorkloadManagementComponent } from './workload-management/workload-management.component';
import { MapTaskQueuesComponent } from './map-task-queues/map-task-queues.component';
import { MapBusinessFunctionsComponent } from './map-business-functions/map-business-functions.component';
import { ManageUserRolesComponent } from './manage-user-roles/manage-user-roles.component';
import { ManageUserProfilesComponent } from './manage-user-profiles/manage-user-profiles.component';
import { SlotManagementComponent } from './slot-management/slot-management.component';
import { ReportsComponent } from './reports/reports.component';
import { AppealsComponent } from './appeals/appeals.component';
import { EnrollmentComponent } from './enrollment/enrollment.component';
import { AdjudicationComponent } from './adjudication/adjudication.component';
import { WaitingListManagementComponent } from './waiting-list-management/waiting-list-management.component';
import { ReferralListManagementComponent } from './referral-list-management/referral-list-management.component';
import { ChangeManagementComponent } from './change-management/change-management.component';
import { TransitionsComponent } from './transitions/transitions.component';
import { NoticesComponent } from './notices/notices.component';
import { DocumentsComponent } from './documents/documents.component';
import { AppointmentsComponent } from './appointments/appointments.component';
import { ReferralComponent } from './referral/referral.component';
import { InboxComponent } from './inbox/inbox.component';
import { PaeSelectProgramComponent } from './pae/pae-select-program/pae-select-program.component';
import { PaeLivingArrangementComponent } from './pae/pae-living-arrangement/pae-living-arrangement.component';
import { PaeContactInformationComponent } from './pae/pae-contact-information/pae-contact-information.component';
import { PaeApplicantInformationComponent } from './pae/pae-applicant-information/pae-applicant-information.component';
import { LeftnavComponent } from './leftnav/leftnav.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { AuditHistoryComponent } from './audit-history/audit-history.component';
import { AuditDetailsComponent } from './audit-details/audit-details.component';
import { AuthGuard } from './core/helpers/auth.guard';
import { PaeAppointmentComponent } from './pae/pae-appointment/pae-appointment.component';
import { AdjudicationSearchComponent } from './adjudication/adjudication-search/adjudication-search.component';
import { AdjudicationDetailsComponent } from './adjudication/adjudication-details/adjudication-details.component';
import { RefApplicantComponent } from './ref-applicant/ref-applicant.component';
import { ReferralSchoolWorkComponent } from './referral-school-work/referral-school-work.component';
import { ReferralSubmitComponent } from './referral-submit/referral-submit.component';
import { RefContactComponent } from './ref-contact/ref-contact.component';
import { RefCareAndSupportComponent } from './ref-care-and-support/ref-care-and-support.component';
import { RefConfirmationComponent } from './ref-confirmation/ref-confirmation.component';

const routes: Routes = [
  { path: '',  redirectTo: '/login', pathMatch: 'full'},
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: LeftnavComponent, canActivate: [AuthGuard], children: [
    {path: 'userDetails', component: UserDetailsComponent, canActivate: [AuthGuard]},
    {path: 'inbox', component: InboxComponent, canActivate: [AuthGuard]},
    {path: 'referral', component: ReferralComponent, canActivate: [AuthGuard]},
    {path: 'referralApplicant', component: RefApplicantComponent, canActivate: [AuthGuard]},
    {path:'referralContact',component:RefContactComponent,canActivate:[AuthGuard]},
    {path: 'referralSchoolAndWork', component: ReferralSchoolWorkComponent, canActivate: [AuthGuard]},
    {path:'referralCareAndSupport',component:RefCareAndSupportComponent,canActivate:[AuthGuard]},
    {path: 'submitReferral', component: ReferralSubmitComponent, canActivate: [AuthGuard]},
    {path:'referralConfirmation',component:RefConfirmationComponent,canActivate:[AuthGuard]}, 
    {path: 'appointments', component: AppointmentsComponent, canActivate: [AuthGuard]},
    {path: 'documents', component: DocumentsComponent, canActivate: [AuthGuard]},
    {path: 'notices', component: NoticesComponent, canActivate: [AuthGuard]},
    {path: 'transitions', component: TransitionsComponent, canActivate: [AuthGuard]},
    {path: 'changeManagement', component: ChangeManagementComponent, canActivate: [AuthGuard]},
    {path: 'referralListManagement', component: ReferralListManagementComponent, canActivate: [AuthGuard]},
    {path: 'waitingListManagement', component: WaitingListManagementComponent, canActivate: [AuthGuard]},
    {path: 'auditHistory', component: AuditHistoryComponent , canActivate: [AuthGuard]},
    {path: 'auditDetails', component: AuditDetailsComponent, canActivate: [AuthGuard]},
    {path: 'adjudicationSearch', component: AdjudicationSearchComponent, canActivate: [AuthGuard]},
    {path: 'adjudicationDetail', component: AdjudicationDetailsComponent, canActivate: [AuthGuard]},
    {path: 'enrollment', component: EnrollmentComponent , canActivate: [AuthGuard]},
    {path: 'appeals', component: AppealsComponent , canActivate: [AuthGuard]},
    {path: 'reports', component: ReportsComponent , canActivate: [AuthGuard]},
    {path: 'slotManagement', component: SlotManagementComponent , canActivate: [AuthGuard]},
    {path: 'manageUserProfiles', component: ManageUserProfilesComponent , canActivate: [AuthGuard]},
    {path: 'manageUserRoles', component: ManageUserRolesComponent , canActivate: [AuthGuard]},
    {path: 'mapBusinessFunctions', component: MapBusinessFunctionsComponent , canActivate: [AuthGuard]},
    {path: 'mapTaskQueues', component: MapTaskQueuesComponent , canActivate: [AuthGuard]},
    {path: 'workLoadManagement', component: WorkloadManagementComponent , canActivate: [AuthGuard]},
    {path: 'qualifiedAssessors', component: QualifiedAssessorsComponent , canActivate: [AuthGuard]},
    {path: 'personReconciliation', component: PersonReconciliationComponent , canActivate: [AuthGuard]}
  ]},
  {path: 'dashboard/pae', component: PaeComponent, canActivate: [AuthGuard], children: [
    {path: 'applicantInformation', component: PaeApplicantInformationComponent, canActivate: [AuthGuard]},
    {path: 'contactInformation', component: PaeContactInformationComponent, canActivate: [AuthGuard]},
    {path: 'livingArrangement', component: PaeLivingArrangementComponent, canActivate: [AuthGuard]},
    {path: 'selectProgram', component: PaeSelectProgramComponent, canActivate: [AuthGuard]},
    {path: 'appointment', component: PaeAppointmentComponent, canActivate: [AuthGuard]}
  ]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
