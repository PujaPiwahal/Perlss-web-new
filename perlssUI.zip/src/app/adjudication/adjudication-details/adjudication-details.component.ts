import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adjudication-details',
  templateUrl: './adjudication-details.component.html',
  styleUrls: ['./adjudication-details.component.scss']
})
export class AdjudicationDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
