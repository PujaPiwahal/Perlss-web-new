import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatRadioChange, MatRadioButton } from '@angular/material/radio';

@Component({
  selector: 'app-pae-contact-information',
  templateUrl: './pae-contact-information.component.html',
  styleUrls: ['./pae-contact-information.component.scss']
})

export class PaeContactInformationComponent implements OnInit {
  myForm: FormGroup;
  isDesignee = true;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      emailAddress: [''],
      cellPhone: [''],
      homePhone: [''],
      workPhone: [''],
      designeeFirstName: [''],
      designeeMiddleName: [''],
      designeeLastName: [''],
      designeeRelationship: [''],
      childRecordRights: [''],
      language: ['']
    });
  }
  saveContactInformation() {

  }

  onChange(mrChange: MatRadioChange) {
    console.log(mrChange.value);
    if (mrChange.value === 'no') {
      this.isDesignee = false;
    }
    else if (mrChange.value === 'yes') {
      this.isDesignee = true;
    }
 }

}
